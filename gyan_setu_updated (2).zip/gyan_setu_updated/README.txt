Gyan Setu - Updated package
---------------------------
Files included:
- index.html         (frontend; OneSignal v16 init included)
- notify.js          (backend Express endpoint; add your REST API key)

Instructions:
1. Unzip and upload index.html to your site root (replace existing index.html).
2. Deploy notify.js on any Node-enabled server (or serverless platform).
   - Before deployment, edit notify.js and replace YOUR_ONESIGNAL_REST_API_KEY_HERE with your OneSignal REST API Key.
   - Install dependencies: npm init -y && npm i express node-fetch
   - Start: node notify.js (or deploy to Vercel/Render/Heroku).
3. Ensure the notify endpoint is reachable at https://www.setugyan.live/api/notify or update the fetch URL in index.html to the correct public URL of your deployed notify endpoint.
4. Test: Upload a file as admin; after successful upload, the frontend will call /api/notify to trigger OneSignal notifications to all subscribers.

Security note:
- Do NOT put the REST API key into client-side files. Keep it in server-side code (notify.js) or environment variables.